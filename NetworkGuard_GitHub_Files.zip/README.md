# 🛡️ NetworkGuard AI — Network Anomaly Detection System using Machine Learning

![Python](https://img.shields.io/badge/Python-3.10+-blue.svg)
![Flask](https://img.shields.io/badge/Backend-Flask-black.svg)
![React](https://img.shields.io/badge/Frontend-React%2019-61dafb.svg)
![Scikit-Learn](https://img.shields.io/badge/ML-Scikit--Learn-orange.svg)
![SQLite](https://img.shields.io/badge/Database-SQLite-003B57.svg)

A full-stack, AI-powered **Network Intrusion Detection & Anomaly Monitoring Platform** that classifies network traffic as **Normal**, **Suspicious**, or **Anomalous** using Machine Learning, and explains every decision with Explainable AI (XAI).

![Dashboard](screenshots/dashboard.png)

---

## 📌 Problem Statement

Modern networks face threats like DDoS floods, port scans, brute-force logins and botnet traffic. Traditional signature-based firewalls only catch attacks they already know. **NetworkGuard AI** combines **supervised ML** (Random Forest, Decision Tree) with **unsupervised anomaly detection** (Isolation Forest) so it can recognise both known attack patterns and unusual, never-seen-before behaviour.

---

## ✨ Features

- **Security Dashboard** — 6 live stat cards (Total Packets, Normal, Anomalous, Threats, Active Connections, Risk Score) and 7 interactive charts
- **Network Traffic Inspection** — full packet log with filters by protocol, status, risk level and IP/port search
- **ML Anomaly Detection Sandbox** — enter 12 network features (or use presets) and get an instant verdict, risk score and XAI reasons
- **Live Monitoring** — real-time streaming charts updated every 1.5 s, with one-click DoS / Port Scan / Brute Force attack injection
- **Security Alerts Console** — severity-ranked alerts (Critical / High / Medium / Low) with View, Review and Resolve actions
- **Attack Analysis** — attack category breakdown, protocol analysis and incident timeline
- **Reports** — daily / weekly / monthly security reports with PDF and CSV export
- **ML Performance** — accuracy, precision, recall, F1, confusion matrix, feature importance and one-click retraining
- **Secure Login** — hashed passwords using Werkzeug

---

## 🧠 Machine Learning Models

| Model | Type | Accuracy | Precision | Recall | F1 Score |
|---|---|---|---|---|---|
| Random Forest | Supervised | 100.0% | 100.0% | 100.0% | 100.0% |
| Decision Tree | Supervised | 100.0% | 100.0% | 100.0% | 100.0% |
| Isolation Forest | Unsupervised | 79.5% | 70.8% | 70.6% | 70.7% |

> **Note:** Models are trained on a synthetically generated network dataset (`backend/ml/dataset_generator.py`). The supervised models score very high because the synthetic attack classes are clearly separable; real-world traffic would give lower scores.

**12 input features:** Flow Duration, Protocol Type, Source Port, Destination Port, Packet Count, Mean Packet Size, Bytes/sec, Packets/sec, Total Flow Bytes, Number of Connections, Connection Duration, Failed Connections.

**Detected attack types:** DoS, DDoS, Port Scan, Brute Force, Botnet, Suspicious Burst.

---

## 🏗️ System Architecture

```
Network Traffic (Simulator / Manual Input)
        │
        ▼
Feature Extraction (12 features)
        │
        ▼
Preprocessing (One-Hot Encoding + Standard Scaling)
        │
   ┌────┴─────────────────────┐
   ▼                          ▼
Random Forest +          Isolation Forest
Decision Tree            (Unsupervised)
   └────┬─────────────────────┘
        ▼
Decision Engine → Attack Type + Risk Score (0–100) + XAI Reasons
        │
   ┌────┴────────┐
   ▼             ▼
SQLite DB    Flask REST API
                 │
                 ▼
        React Dashboard (UI)
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 19, Tailwind CSS v4, Recharts, Lucide Icons |
| Backend | Python, Flask, Flask-CORS |
| Machine Learning | Scikit-learn, Pandas, NumPy, Joblib |
| Database | SQLite 3 |
| Simulator | Multi-threaded Python traffic generator |

---

## 📂 Project Structure

```
NetworkGuard-AI/
├── screenshots/
├── README.md
└── DSL/
    ├── backend/
    │   ├── app.py           # Flask server + REST API
    │   ├── database.py      # SQLite setup & seed data
    │   ├── simulator.py     # Live traffic simulator
    │   ├── ml/              # Dataset generator, training, predictor
    │   ├── models/          # Trained .pkl models + metrics.json
    │   └── requirements.txt
    ├── frontend/
    │   └── dist/            # Built React dashboard (served by Flask)
    └── run_all.bat
```

---

## 🚀 How to Run

### Requirements
- Python 3.10 or higher

### Steps

```bash
# 1. Clone the repository
git clone https://github.com/hinalmachhi/NetworkGuard-AI.git
cd NetworkGuard-AI/DSL/backend

# 2. Install dependencies
python -m pip install -r requirements.txt

# 3. (Optional) Retrain the ML models
python ml/train_models.py

# 4. Start the server
python app.py
```

Open **http://localhost:5000** in your browser.

### 🔑 Default Login
| Username | Password |
|---|---|
| `admin` | `admin123` |

---

## 📸 Screenshots

### Network Traffic Inspection
![Network Traffic](screenshots/network-traffic.png)

### ML Anomaly Detection Sandbox
![Anomaly Detection](screenshots/anomaly-detection.png)

### Live Monitoring
![Live Monitoring](screenshots/live-monitoring.png)

### Security Alerts
![Alerts](screenshots/alerts.png)

### Attack Analysis
![Attack Analysis](screenshots/attack-analysis.png)

### Security Reports
![Reports](screenshots/reports.png)

### ML Model Performance
![ML Performance](screenshots/ml-performance.png)

---

## 🔌 API Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `/api/auth/login` | POST | Admin login |
| `/api/dashboard` | GET | Dashboard stats and chart data |
| `/api/traffic` | GET | Filtered packet logs |
| `/api/predict` | POST | ML prediction on 12 features |
| `/api/traffic/live` | GET | Live traffic buffer |
| `/api/simulation/start` | POST | Start traffic simulator |
| `/api/simulation/stop` | POST | Stop traffic simulator |
| `/api/simulation/inject` | POST | Inject an attack (DoS, Port Scan, etc.) |
| `/api/alerts` | GET | List security alerts |
| `/api/alerts/<id>` | PATCH | Mark alert Reviewed / Resolved |
| `/api/attack-analysis` | GET | Attack and protocol breakdown |
| `/api/model-performance` | GET | Model metrics |
| `/api/model-performance/retrain` | POST | Retrain models |
| `/api/reports` | GET | Generate security report |
| `/api/reports/export-csv` | GET | Export traffic or alerts as CSV |

---

## 🔮 Future Scope

- Capture real network packets using Scapy / Wireshark instead of simulated data
- Train on public datasets like CICIDS2017 or NSL-KDD
- Add deep learning models (LSTM / Autoencoders)
- Email / SMS alerts for critical threats
- Cloud deployment

---

## 👩‍💻 Author

Developed by [@hinalmachhi](https://github.com/hinalmachhi)

---

⭐ If you found this project useful, give it a star!
